#!/bin/bash
echo "Starting CodeBeats GUI..."
./codebeats-gui "$@"
