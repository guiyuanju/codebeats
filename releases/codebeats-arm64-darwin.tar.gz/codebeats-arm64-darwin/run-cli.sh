#!/bin/bash
echo "Starting CodeBeats CLI..."
echo "Press Ctrl+C to exit"
./codebeats "$@"
