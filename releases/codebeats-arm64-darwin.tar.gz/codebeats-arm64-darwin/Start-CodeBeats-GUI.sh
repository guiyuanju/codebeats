#!/bin/bash
echo "🎵 Starting CodeBeats GUI..."
echo "   Close this window to exit CodeBeats"
echo ""
./codebeats-gui
